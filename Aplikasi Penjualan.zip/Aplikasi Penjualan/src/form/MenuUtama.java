/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package form;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import koneksi.KoneksiDB;

/**
 *
 * @author code purun
 */
public class MenuUtama extends javax.swing.JFrame {
     
    public MenuUtama() {
        initComponents();
        Dimension screen=Toolkit.getDefaultToolkit().getScreenSize();
        this.setSize(screen.width,screen.height);
        setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
        btn_ubahBrg.setEnabled(false);
        btn_hapusBrg.setEnabled(false);
        btn_ubahPlg.setEnabled(false);
        btn_hapusPlg.setEnabled(false);
        // fungsi close aplikasi
        this.addWindowListener(new WindowAdapter(){           
            public void windowClosing(WindowEvent e){
                doExit();
            }
            private void doExit() {
                int confirm = JOptionPane.showConfirmDialog(null, "Apakah anda yakin keluar dari Program?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
                if(confirm == JOptionPane.YES_OPTION){
                    System.exit(0);
                }     
            }
        });
    }
    
    //tampil data barang
    public void tampilBarang(){       
        Object []baris = {"Kode Barang","Nama Barang","Harga","Stok"};
        DefaultTableModel tabmode = new DefaultTableModel(null, baris);
        tbl_Barang.setModel(tabmode);      
        try {
            Statement st = (Statement)KoneksiDB.GetConnection().createStatement();
            ResultSet hasil = st.executeQuery("select * from tbl_barang");
            while (hasil.next()){
                String kd = hasil.getString("kd_barang");
                String nama = hasil.getString("nm_barang");
                String harga = hasil.getString("harga");
                String stok = hasil.getString("stok");              
                String[] data = {kd, nama, harga, stok};
                tabmode.addRow(data);               
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Menampilkan data GAGAL","Informasi", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    //tampil data pelanggan
    public void tampilPelanggan(){       
        Object []baris = {"Kode Pelanggan","Nama Pelanggan","Alamat","No Telepon"};
        DefaultTableModel tabmode = new DefaultTableModel(null, baris);
        tbl_Pelanggan.setModel(tabmode);      
        try {
            Statement st = (Statement)KoneksiDB.GetConnection().createStatement();
            ResultSet hasil = st.executeQuery("select * from tbl_pelanggan");
            while (hasil.next()){
                String kd = hasil.getString("kd_pelanggan");
                String nama = hasil.getString("nm_pelanggan");
                String alamat = hasil.getString("alamat");
                String no = hasil.getString("no_tlp");              
                String[] data = {kd, nama, alamat, no};
                tabmode.addRow(data);               
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Menampilkan data GAGAL","Informasi", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    //code hapus data barang
    public void hapusBarang() {
        if(txt_CariBarang.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null, "Silahkan Pilih Data yang akan dihapus.");
        }else{
            String nama = txt_CariBarang.getText();
            try{
                Statement statement = (Statement)KoneksiDB.GetConnection().createStatement();
                int confirm = JOptionPane.showConfirmDialog(this, "Apakah anda yakin data akan dihapus?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
                if(confirm == JOptionPane.YES_OPTION){
                    statement.executeUpdate("DELETE from tbl_barang where nm_barang=('" + nama +"');");
                    JOptionPane.showMessageDialog(null, "Data berhasil dihapus");
                    txt_CariBarang.setText("");
                }                         
            }catch (Exception t){
                JOptionPane.showMessageDialog(null, "Data gagal dihapus");
            }
            tampilBarang();
        }
    }
    
    //code hapus data pelanggan
    public void hapusPelanggan() {
        if(txt_CariPlg.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null, "Silahkan Pilih Data yang akan dihapus.");
        }else{
            String nama = txt_CariPlg.getText();
            try{
                Statement statement = (Statement)KoneksiDB.GetConnection().createStatement();
                int confirm = JOptionPane.showConfirmDialog(this, "Apakah anda yakin data akan dihapus?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
                if(confirm == JOptionPane.YES_OPTION){
                    statement.executeUpdate("DELETE from tbl_pelanggan where nm_pelanggan=('" + nama +"');");
                    JOptionPane.showMessageDialog(null, "Data berhasil dihapus");
                    txt_CariPlg.setText("");
                }                         
            }catch (Exception t){
                JOptionPane.showMessageDialog(null, "Data gagal dihapus");
            }
            tampilPelanggan();
        }
    }
    
    //code pencarian barang
    public void cariBarang(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("Kode Barang");
        tbl.addColumn("Nama Barang");
        tbl.addColumn("Harga");
        tbl.addColumn("tok");
        tbl_Barang.setModel(tbl);
        try{
            com.mysql.jdbc.Statement statement = (com.mysql.jdbc.Statement)KoneksiDB.GetConnection().createStatement();
            ResultSet res = statement.executeQuery("select * from tbl_barang where nm_barang like '%"+ txt_CariBarang.getText() + "%'");
            while (res.next()){
                tbl.addRow(new Object[]{
                    res.getString("kd_barang"),
                    res.getString("nm_barang"),
                    res.getString("harga"),
                    res.getString("stok"),                   
                });
                tbl_Barang.setModel(tbl);
            }
        }catch (Exception e){
            JOptionPane.showMessageDialog(rootPane, "Akses Gagal");
        }
    }
    
    //code pencarian pelanggan
    public void cariPelanggan(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("Kode Pelanggan");
        tbl.addColumn("Nama Pelanggan");
        tbl.addColumn("Alamat");
        tbl.addColumn("No Telepon");
        tbl_Pelanggan.setModel(tbl);
        try{
            com.mysql.jdbc.Statement statement = (com.mysql.jdbc.Statement)KoneksiDB.GetConnection().createStatement();
            ResultSet res = statement.executeQuery("select * from tbl_pelanggan where nm_pelanggan like '%"+ txt_CariPlg.getText() + "%'");
            while (res.next()){
                tbl.addRow(new Object[]{
                    res.getString("kd_pelanggan"),
                    res.getString("nm_pelanggan"),
                    res.getString("alamat"),
                    res.getString("no_tlp"),                   
                });
                tbl_Pelanggan.setModel(tbl);
            }
        }catch (Exception e){
            JOptionPane.showMessageDialog(rootPane, "Akses Gagal");
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        Barang = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        btn_tambahBrg = new javax.swing.JButton();
        txt_CariBarang = new javax.swing.JTextField();
        btn_ubahBrg = new javax.swing.JButton();
        btn_hapusBrg = new javax.swing.JButton();
        btn_tampilBrg = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_Barang = new javax.swing.JTable();
        Pelanggan = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        btn_tambahPlg = new javax.swing.JButton();
        txt_CariPlg = new javax.swing.JTextField();
        btn_ubahPlg = new javax.swing.JButton();
        btn_hapusPlg = new javax.swing.JButton();
        btn_tampilPlg = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_Pelanggan = new javax.swing.JTable();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        mn_keluar = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));

        jPanel2.setBackground(new java.awt.Color(255, 51, 51));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Aplikasi Penjualan");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Barang.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jPanel9.setBackground(new java.awt.Color(51, 51, 51));

        btn_tambahBrg.setText("Tambah");
        btn_tambahBrg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambahBrgActionPerformed(evt);
            }
        });

        txt_CariBarang.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txt_CariBarang.setForeground(new java.awt.Color(153, 153, 153));
        txt_CariBarang.setText("Cari nama barang");
        txt_CariBarang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt_CariBarangMouseClicked(evt);
            }
        });
        txt_CariBarang.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_CariBarangKeyTyped(evt);
            }
        });

        btn_ubahBrg.setText("Ubah");
        btn_ubahBrg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ubahBrgActionPerformed(evt);
            }
        });

        btn_hapusBrg.setText("Hapus");
        btn_hapusBrg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusBrgActionPerformed(evt);
            }
        });

        btn_tampilBrg.setText("Tampil Data");
        btn_tampilBrg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tampilBrgActionPerformed(evt);
            }
        });

        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/Search_24x24.png"))); // NOI18N
        jLabel4.setText("i");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btn_tambahBrg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_ubahBrg, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_hapusBrg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_tampilBrg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 208, Short.MAX_VALUE)
                .addComponent(txt_CariBarang, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addGap(7, 7, 7))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_tambahBrg)
                    .addComponent(txt_CariBarang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_ubahBrg)
                    .addComponent(btn_hapusBrg)
                    .addComponent(btn_tampilBrg)
                    .addComponent(jLabel4))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tbl_Barang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Kode Barang", "Nama Barang", "Harga", "Stok"
            }
        ));
        tbl_Barang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_BarangMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_Barang);

        javax.swing.GroupLayout BarangLayout = new javax.swing.GroupLayout(Barang);
        Barang.setLayout(BarangLayout);
        BarangLayout.setHorizontalGroup(
            BarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(BarangLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
        );
        BarangLayout.setVerticalGroup(
            BarangLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BarangLayout.createSequentialGroup()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Data Barang", Barang);

        Pelanggan.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jPanel10.setBackground(new java.awt.Color(51, 51, 51));

        btn_tambahPlg.setText("Tambah");
        btn_tambahPlg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambahPlgActionPerformed(evt);
            }
        });

        txt_CariPlg.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txt_CariPlg.setForeground(new java.awt.Color(153, 153, 153));
        txt_CariPlg.setText("Cari nama pelanggan");
        txt_CariPlg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt_CariPlgMouseClicked(evt);
            }
        });
        txt_CariPlg.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txt_CariPlgKeyTyped(evt);
            }
        });

        btn_ubahPlg.setText("Ubah");
        btn_ubahPlg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ubahPlgActionPerformed(evt);
            }
        });

        btn_hapusPlg.setText("Hapus");
        btn_hapusPlg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusPlgActionPerformed(evt);
            }
        });

        btn_tampilPlg.setText("Tampil Data");
        btn_tampilPlg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tampilPlgActionPerformed(evt);
            }
        });

        jLabel6.setForeground(new java.awt.Color(51, 51, 51));
        jLabel6.setText("i");

        jLabel7.setForeground(new java.awt.Color(51, 51, 51));
        jLabel7.setText("i");

        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/Search_24x24.png"))); // NOI18N
        jLabel8.setText("i");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btn_tambahPlg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_ubahPlg, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_hapusPlg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_tampilPlg)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 206, Short.MAX_VALUE)
                .addComponent(txt_CariPlg, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addGap(7, 7, 7))
            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel10Layout.createSequentialGroup()
                    .addGap(376, 376, 376)
                    .addComponent(jLabel7)
                    .addContainerGap(377, Short.MAX_VALUE)))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_tambahPlg)
                    .addComponent(txt_CariPlg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_ubahPlg)
                    .addComponent(btn_hapusPlg)
                    .addComponent(btn_tampilPlg)
                    .addComponent(jLabel6)
                    .addComponent(jLabel8))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel10Layout.createSequentialGroup()
                    .addGap(10, 10, 10)
                    .addComponent(jLabel7)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        tbl_Pelanggan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Kode Pelanggan", "Nama Pelanggan", "Alamat", "No Telepon"
            }
        ));
        tbl_Pelanggan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_PelangganMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_Pelanggan);

        javax.swing.GroupLayout PelangganLayout = new javax.swing.GroupLayout(Pelanggan);
        Pelanggan.setLayout(PelangganLayout);
        PelangganLayout.setHorizontalGroup(
            PelangganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PelangganLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3)
                .addContainerGap())
        );
        PelangganLayout.setVerticalGroup(
            PelangganLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PelangganLayout.createSequentialGroup()
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Data Pelanggan", Pelanggan);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 815, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Data Suplier", jPanel7);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 815, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Penjualan Barang", jPanel8);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        jMenu1.setText("File");

        mn_keluar.setText("Log Out");
        mn_keluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mn_keluarActionPerformed(evt);
            }
        });
        jMenu1.add(mn_keluar);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Ubah");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_tambahBrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambahBrgActionPerformed
        new FormInputBarang().setVisible(true);
    }//GEN-LAST:event_btn_tambahBrgActionPerformed

    private void txt_CariBarangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_CariBarangMouseClicked
        txt_CariBarang.setText("");
        txt_CariBarang.setForeground(Color.black);
    }//GEN-LAST:event_txt_CariBarangMouseClicked

    private void txt_CariBarangKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_CariBarangKeyTyped
        cariBarang();
    }//GEN-LAST:event_txt_CariBarangKeyTyped

    private void btn_ubahBrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ubahBrgActionPerformed
        new FormUbahBarang().setVisible(true);
    }//GEN-LAST:event_btn_ubahBrgActionPerformed

    private void btn_hapusBrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusBrgActionPerformed
        hapusBarang();
    }//GEN-LAST:event_btn_hapusBrgActionPerformed

    private void btn_tampilBrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tampilBrgActionPerformed
        tampilBarang();
        btn_tampilBrg.setEnabled(false);
    }//GEN-LAST:event_btn_tampilBrgActionPerformed

    private void tbl_BarangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_BarangMouseClicked
        int baris = tbl_Barang.getSelectedRow();
        txt_CariBarang.setText((String)tbl_Barang.getValueAt(baris, 1));
        btn_ubahBrg.setEnabled(true);
        btn_hapusBrg.setEnabled(true);
        txt_CariBarang.setForeground(Color.black);
    }//GEN-LAST:event_tbl_BarangMouseClicked

    private void btn_tambahPlgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambahPlgActionPerformed
        new FormInputPelanggan().setVisible(true);
    }//GEN-LAST:event_btn_tambahPlgActionPerformed

    private void txt_CariPlgMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_CariPlgMouseClicked
        txt_CariPlg.setText("");
        txt_CariPlg.setForeground(Color.black);
    }//GEN-LAST:event_txt_CariPlgMouseClicked

    private void txt_CariPlgKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_CariPlgKeyTyped
        cariPelanggan();
    }//GEN-LAST:event_txt_CariPlgKeyTyped

    private void btn_ubahPlgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ubahPlgActionPerformed
        new FormUbahPelanggan().setVisible(true);
    }//GEN-LAST:event_btn_ubahPlgActionPerformed

    private void btn_hapusPlgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusPlgActionPerformed
        hapusPelanggan();
    }//GEN-LAST:event_btn_hapusPlgActionPerformed

    private void btn_tampilPlgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tampilPlgActionPerformed
        tampilPelanggan();
        btn_tampilPlg.setEnabled(false);
    }//GEN-LAST:event_btn_tampilPlgActionPerformed

    private void tbl_PelangganMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_PelangganMouseClicked
        int baris = tbl_Pelanggan.getSelectedRow();
        txt_CariPlg.setText((String)tbl_Pelanggan.getValueAt(baris, 1));
        btn_ubahPlg.setEnabled(true);
        btn_hapusPlg.setEnabled(true);
        txt_CariPlg.setForeground(Color.black);
    }//GEN-LAST:event_tbl_PelangganMouseClicked

    private void mn_keluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mn_keluarActionPerformed
        int confirm = JOptionPane.showConfirmDialog(null, "Apakah anda yakin Log Out?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
            if(confirm == JOptionPane.YES_OPTION){
                Login l = new Login();
                l.setVisible(true);
            }
            dispose();
    }//GEN-LAST:event_mn_keluarActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuUtama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuUtama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuUtama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuUtama.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuUtama().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Barang;
    private javax.swing.JPanel Pelanggan;
    private javax.swing.JButton btn_hapusBrg;
    private javax.swing.JButton btn_hapusPlg;
    private javax.swing.JButton btn_tambahBrg;
    private javax.swing.JButton btn_tambahPlg;
    private javax.swing.JButton btn_tampilBrg;
    private javax.swing.JButton btn_tampilPlg;
    public static javax.swing.JButton btn_ubahBrg;
    public static javax.swing.JButton btn_ubahPlg;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JMenuItem mn_keluar;
    public static javax.swing.JTable tbl_Barang;
    public static javax.swing.JTable tbl_Pelanggan;
    private javax.swing.JTextField txt_CariBarang;
    private javax.swing.JTextField txt_CariPlg;
    // End of variables declaration//GEN-END:variables
}
